const express = require('express');
const router = express.Router();
const mainController = require('../controller/controller');



const { obtenerNotas } = require('../controller/controller'); // Importa la función desde el controlador

// Define la ruta para obtener las notas
router.get('/notas/:usuario_Id', obtenerNotas);

module.exports = router;

// Definir las rutas
router.get('/home', mainController.index); // Página principal
router.get('/crear', mainController.crear);
router.get('/inisesion', mainController.inisesion);
router.get('/mas', mainController.mas);
router.get('/miboletin', mainController.miboletin);

router.get('/carga', mainController.carga);
router.get('/inic', mainController.inic);
router.get('/ini2', mainController.ini2);
router.get('/selec', mainController.selec);
module.exports = router;