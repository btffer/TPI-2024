const express = require('express');
const router = express.Router();
const mainController = require('../controller/controller');







// Define la ruta para obtener las notas

module.exports = router;

// Definir las rutas
router.get('/home', mainController.index); // Página principal
router.get('/crear', mainController.crear);
router.get('/inisesion', mainController.inisesion);
router.get('/miboleti', mainController.miboleti);
router.get('/ini', mainController.ini);

router.get('/espera', mainController.espera);
router.get('/ini2', mainController.ini2);
router.get('/selec', mainController.selec);

router.get('/iniad', mainController.iniad);
router.get('/selusu', mainController.selusu);


module.exports = router;