const button = document.querySelector('#button');
const form = document.querySelector('#formulario');

button.addEventListener('click',async ()=>{
    event.preventDefault()
    const formData = new FormData(formulario);

    const alumno = {
        nombre: formData.get('nombre'),
        contraseña: formData.get('contra'),
        correo: formData.get('correo'),
        dni: formData.get('dni')
    }


    const response = await fetch('http://localhost:3000/validar',{
        method:'POST',
        headers: {
            'Content-Type': 'application/json' 
        },
        body: JSON.stringify(alumno)
    })

    if(response.status == 200){
        console.log('Alumno creado correctamente');
        window.location.replace('http://localhost:3000/inisesion');
    }

    
})