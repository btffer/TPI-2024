let tiposDeNota = {}; // Aquí almacenaremos los tipos de nota obtenidos del servidor

// Función para obtener el usuario desde la cookie
function obtenerUsuarioDesdeCookie() {
    const cookies = document.cookie.split('; ');
    for (let cookie of cookies) {
        const [key, value] = cookie.split('=');
        if (key === 'usuario') {
            return value; // Retorna el nombre de usuario almacenado en la cookie
        }
    }
    return null; // Si no se encuentra, retorna null
}

// Función para obtener los tipos de nota desde el servidor
async function obtenerTiposNota() {
    try {
        const response = await fetch('http://localhost:3000/obtener/tipos-nota');
        if (!response.ok) {
            throw new Error(`Error al obtener los tipos de nota: ${response.status}`);
        }

        // Obtener los tipos de nota en formato JSON
        const tipos = await response.json();

        // Mapear los tipos de nota para acceder fácilmente a ellos por su tipo_id
        tipos.forEach(tipo => {
            tiposDeNota[tipo.tipo_id] = tipo.tipo; // Asociar tipo_id con tipo
        });
    } catch (error) {
        console.error('Error al obtener los tipos de nota:', error);
    }
}

// Función para cargar las notas y mostrar en el HTML
async function cargarNotas() {
    try {
        // Obtener el usuario desde la cookie
        const usuario = obtenerUsuarioDesdeCookie();
        if (!usuario) {
            alert('No se ha encontrado el usuario. Asegúrate de haber iniciado sesión.');
            return;
        }

        // Solicitar las notas al servidor
        const response = await fetch('http://localhost:3000/obtener/notas');
        if (!response.ok) {
            throw new Error(`Error al obtener las notas: ${response.status}`);
        }

        // Obtener las notas en formato JSON
        const notas = await response.json();

        // Filtrar las notas para el usuario actual
        const notasDelUsuario = notas.filter((usuarioNota) => usuarioNota.usuario_id === usuario);

        // Mapeo de tipo de nota a ID del elemento
        const tipoDeNotaAElemento = {
            '1er informe 1er cuatrimestre': 'cuatrimestre1',
            '2do informe 1er cuatrimestre': 'cuatrimestre2',
            'nota 1er cuatrimestre': 'cuatrimestre-nota1',
            '1er informe': 'cuatrimestre1-2',
            '2do informe': 'cuatrimestre2-2',
            'nota 2do cuatrimestre': 'cuatrimestre-nota2'
        };

        // Iterar sobre las notas del usuario y sus materias
        notasDelUsuario.forEach((usuario) => {
            Object.entries(usuario.materias).forEach(([materiaId, materias]) => {
                materias.forEach((materia) => {
                    const tipoNota = tiposDeNota[materia.tipo_de_nota];
                    // Verificar si el tipo de nota está en el mapeo
                    if (tipoDeNotaAElemento[tipoNota]) {
                        const elementId = `materia${materiaId}-${tipoDeNotaAElemento[tipoNota]}`;
                        const element = document.getElementById(elementId);

                        // Verificar si el elemento existe y asignar la nota
                        if (element) {
                            element.textContent = `${materia.nota}`;
                        } else {
                            console.warn(`Elemento con ID ${elementId} no encontrado.`);
                        }
                    }
                });
            });
        });
    } catch (error) {
        console.error('Error al cargar las notas:', error);
    }
}

// Ejecutar la función para cargar los tipos de nota y luego cargar las notas
window.onload = async () => {
    await obtenerTiposNota(); // Cargar los tipos de nota
    cargarNotas();            // Luego cargar las notas
};
