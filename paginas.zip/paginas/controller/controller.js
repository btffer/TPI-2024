const mainController = {};

// Retorna la vista de pag principal
mainController.index = async (req, res) =>{
  return res.render("index.ejs",);
};
mainController.ini = async (req, res) =>{
  return res.render("inicio.ejs",);
};
// pag de alumnos
mainController.crear = async (req, res) =>{
    return res.render("crear.ejs",);
  };
  mainController.inisesion = async (req, res) =>{
    return res.render("inicio sesion.ejs",);
  };


  mainController.miboletin = async (req, res) =>{
    return res.render("mi boletin.ejs",);
  };

  mainController.espera = async (req, res) =>{
    return res.render("espera.ejs",);
  };
  mainController.usu = async (req, res) =>{
    return res.render("usuario.ejs",);
  };


// pag de usuario de carga



  mainController.ini2 = async (req, res) =>{
    return res.render("inicio2.ejs",);
  };
  mainController.selec = async (req, res) =>{
    return res.render("seleccionar.ejs",);
  };

  mainController.notas = async (req, res) => {
    try {
      // Obtener el ID del usuario logueado
      const usuarioId = req.session.usuarios.usuario_id;
      console.log("ID Usuario: ", usuarios);
  
      // Consultar el usuario con sus relaciones
      const usuario = await bd.usuarios.findOne({
        where: { usuarios: usuarioId },
        include: [{
          model: bd.Curso,
          as: 'curso',
          attributes: ['nombre_curso'], // Atributos del curso
          include: [{
            model: bd.Materia,
            as: 'materias',
            include: [{
              model: bd.Nota,
              as: 'notas',
              attributes: ['nota', 'cuatrimestre', 'informe'], // Atributos de Nota
              required: false // Permitir que algunas materias no tengan notas
            }]
          }]
        }]
      });
  
      if (!usuario) {
        return res.status(404).send("Usuario no encontrado");
      }
  
      // Renderizar la vista 'miboletin'
      return res.render("mi_boletin", { usuario });
    } catch (error) {
      console.error("Error al obtener el usuario con el curso:", error.message);
      res.status(500).send("Error en el servidor");
    }
  };
  
module.exports = mainController;
    

 

