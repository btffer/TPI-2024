const mainController = {};

// Retorna la vista de pag principal
mainController.index = async (req, res) =>{
  return res.render("inicio.ejs",);
};
// pag de alumnos
mainController.crear = async (req, res) =>{
    return res.render("crear.ejs",);
  };
  mainController.inisesion = async (req, res) =>{
    return res.render("inicio sesion.ejs",);
  };

  mainController.mas = async (req, res) =>{
    return res.render("mas boletines.ejs",);
  };
  mainController.miboletin = async (req, res) =>{
    return res.render("mi boletin.ejs",);
  };

  mainController.esperar = async (req, res) =>{
    return res.render("espera.ejs",);
  };
  mainController.usu = async (req, res) =>{
    return res.render("usuario.ejs",);
  };
  mainController.index = async (req, res) =>{
    return res.render("index.ejs",);
  };


// pag de usuario de carga
mainController.carga = async (req, res) =>{
    return res.render("carga.ejs",);
  };

  mainController.inic = async (req, res) =>{
    return res.render("iniciar.ejs",);
  };
  mainController.ini2 = async (req, res) =>{
    return res.render("inicio2.ejs",);
  };
  mainController.selec = async (req, res) =>{
    return res.render("seleccionar.ejs",);
  };




module.exports = mainController;
    

 

