const mainController = {};

// Retorna la vista de pag principal
mainController.index = async (req, res) =>{
  return res.render("index.ejs",);
};
mainController.ini = async (req, res) =>{
  return res.render("inicio.ejs",);
};
// pag de alumnos
mainController.crear = async (req, res) =>{
    return res.render("crear.ejs",);
  };
  mainController.inisesion = async (req, res) =>{
    return res.render("inicio sesion.ejs",);
  };


  mainController.miboleti = async (req, res) =>{
    return res.render("mi boletin.ejs",);
  };

  mainController.espera = async (req, res) =>{
    return res.render("espera.ejs",);
  };
  mainController.usu = async (req, res) =>{
    return res.render("usuario.ejs",);
  };


// pag de usuario de carga



  mainController.ini2 = async (req, res) =>{
    return res.render("inicio2.ejs",);
  };
  mainController.selec = async (req, res) =>{
    return res.render("seleccionar.ejs",);
  };
  
module.exports = mainController;
    

 

