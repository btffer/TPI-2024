const mainController = {};
const bd = require("../database/models");
const bcrypt = require('bcrypt'); // Asegúrate de instalar bcrypt

mainController.index = async (req, res) => {
    try {
        const cursos = await bd.Curso.findAll();
        res.render("index", { cursos }); // Pasar cursos como un objeto
    } catch (error) {
        console.error("Error al obtener cursos:", error);
        res.status(500).send("Error al cargar la página de inicio");
    }
};

