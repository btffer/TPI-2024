// server.js
const express = require('express');
const mysql = require('mysql2');
const path = require('path');

const app = express();
const port = 3000;


// Crear conexión a la base de datos MySQL
const connection = mysql.createConnection({
  host: '127.0.0.1',
  user: 'root',
  password: null,
  database: 'base de datos'
});

// Conectar a la base de datos
connection.connect((err) => {
  if (err) {
    console.error('Error de conexión: ' + err.stack);
    return;
  }
  console.log('Conectado a la base de datos');
});

// Servir archivos estáticos desde la carpeta "public"
const publico = path.resolve(__dirname, "../");
app.use(express.static(publico));

app.use(express.json());
app.use(express.urlencoded({extended:false}));


// Iniciar el servidor
app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});

app.use("/", require("../router/router.js"));

// Configurar el motor de vistas a usar
app.set("view engine", "ejs");

// Rutas a las carpetas de vistas
const vistasCarpeta1 = path.resolve(__dirname, "../pagina de alumno");
const vistasCarpeta2 = path.resolve(__dirname, "../pagina de carga");
const vistasCarpeta3 = path.resolve(__dirname, "../pagina de admin");

// Establecer ambas carpetas de vistas
app.set("views", [vistasCarpeta1, vistasCarpeta2, vistasCarpeta3]);

app.post("/validar",function(req,res){
  const datos= req.body;

  let nombre= datos.nombre
  let contra= datos.contraseña
  let correo= datos.correo
  let dni= datos.dni
  
  
  let reg="INSERT INTO usuarios (usuario_id, contraseña	, correo, dni)VALUES('"+nombre+"','"+contra+"','"+correo+"','"+dni+"')";
  connection.query(reg,function(error){
    if(error){
      throw error;
    }else{
      res.send('Usuario creado')
    }
  })
})



app.post("/validar2", function(req, res) {
  const da = req.body;

  const nombre = da.username;
  const contra = da.password;

  // Consulta para verificar si el usuario existe en la base de datos y obtener su tipo de usuario
  let query = "SELECT tipo_de_usuario_id FROM usuarios WHERE usuario_id = ? AND contraseña = ?";
  
  // Usa placeholders para evitar inyección SQL
  connection.query(query, [nombre, contra], function(error, results) {
    if (error) {
      throw error;
    }

    if (results.length > 0) {
      // Si el usuario existe, obtenemos su tipo de usuario
      const tipoUsuario = results[0].tipo_de_usuario_id;

      // Redirigir a diferentes páginas según el tipo de usuario
      if (tipoUsuario === 1) {
        res.redirect("/ini"); // Página para usuarios tipo 1 (alumno)
      } else if (tipoUsuario === 2) {
        res.redirect("/ini2"); // Página para usuarios tipo 2 (alumnado)
      } else if(tipoUsuario === 3){
        res.redirect("/iniad");
      }else {
        res.redirect("/espera");
      }
    } else {
      // Si el usuario no existe, redireccionar al index
      res.redirect("/home");
    }
  });
});
app.post("/validar3",function(req,res){
  const datos= req.body;

  let nom= datos.nom
  let cur= datos.curso
  let año= datos.año
  let mat= datos.mat
  let nota= datos.nota
  let tipo= datos.tipo

  let regk="INSERT INTO `nota` (usuario_id, curso, año, materia, nota, tipo_de_nota) VALUES('"+nom+"','"+cur+"','"+año+"','"+mat+"','"+nota+"','"+tipo+"')";
  connection.query(regk,function(error){
    if(error){
      throw error;
    }else{
      console.log("bien");
      res.redirect("/ini2");
    }
  })
})

app.post("/validar4", function (req, res) {
  const datos = req.body;

  // Asignamos los datos provenientes de la solicitud
  let nombre = datos.nom; // Nombre del usuario
  let tipoUsuario = datos.selec; // Nuevo tipo de usuario

  // Verificamos si el usuario existe en la base de datos
  let verificarUsuario = "SELECT * FROM usuarios WHERE usuario_id = ?";
  connection.query(verificarUsuario, [nombre], function (error, results) {
    if (error) {
      console.error("Error al verificar el usuario:", error);
      res.status(500).send("Error interno del servidor");
    } else {
      if (results.length > 0) {
        // Si el usuario existe, actualizamos el tipo de usuario
        let actualizarTipo = "UPDATE usuarios SET tipo_de_usuario_id = ? WHERE usuario_id = ?";
        connection.query(actualizarTipo, [tipoUsuario, nombre], function (error) {
          if (error) {
            console.error("Error al actualizar el tipo de usuario:", error);
            res.status(500).send("Error interno del servidor");
          } else {
  
            res.redirect("/iniad");
          }
        });
      } else {
        // Si el usuario no existe
        res.status(404).send("Usuario no encontrado");
      }
    }
  });
});


app.get('/obtener/notas', (req, res) => {
  // Consulta SQL para obtener las notas agrupadas
  const query = `SELECT usuario_id, curso, año, materia, nota, tipo_de_nota 
                 FROM nota
                 ORDER BY usuario_id, curso, año, materia, tipo_de_nota`;

  connection.query(query, (error, resultados) => {
      if (error) {
          console.error(error);
          return res.status(500).json({ error: 'Error al obtener las notas' });
      }

      // Agrupar las notas por usuario y materia
      const notas = [];
      let usuarioActual = null;
      let materias = {};

      resultados.forEach((nota) => {
          if (usuarioActual !== nota.usuario_id) {
              if (usuarioActual !== null) {
                  // Guardar las materias de usuario anterior
                  notas.push({ usuario_id: usuarioActual, materias });
              }
              usuarioActual = nota.usuario_id;
              materias = {};
          }

          if (!materias[nota.materia]) {
              materias[nota.materia] = [];
          }
          materias[nota.materia].push({ tipo_de_nota: nota.tipo_de_nota, nota: nota.nota });
      });

      // Agregar el último usuario procesado
      if (usuarioActual !== null) {
          notas.push({ usuario_id: usuarioActual, materias });
      }

      res.json(notas);
  });
});

app.get('/obtener/tipos-nota', (req, res) => {
  const query = "SELECT * FROM `tipo de nota`";
  
  connection.query(query, (err, results) => {
    if (err) {
      console.error('Error al consultar la base de datos', err);
      res.status(500).send('Error en el servidor');
      return;
    }
    res.json(results);
  });
});