// server.js
const express = require('express');
const mysql = require('mysql2');
const path = require('path');

const app = express();
const port = 3000;


// Crear conexión a la base de datos MySQL
const connection = mysql.createConnection({
  host: '127.0.0.1',
  user: 'root',
  password: null,
  database: 'base de datos'
});

// Conectar a la base de datos
connection.connect((err) => {
  if (err) {
    console.error('Error de conexión: ' + err.stack);
    return;
  }
  console.log('Conectado a la base de datos');
});

// Servir archivos estáticos desde la carpeta "public"
const publico = path.resolve(__dirname, "../");
app.use(express.static(publico));

app.use(express.json());
app.use(express.urlencoded({extended:false}));


// Iniciar el servidor
app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});

app.use("/", require("../router/router.js"));

// Configurar el motor de vistas a usar
app.set("view engine", "ejs");

// Rutas a las carpetas de vistas
const vistasCarpeta1 = path.resolve(__dirname, "../pagina de alumno");
const vistasCarpeta2 = path.resolve(__dirname, "../pagina de carga");

// Establecer ambas carpetas de vistas
app.set("views", [vistasCarpeta1, vistasCarpeta2]);

app.post("/validar",function(req,res){
  const datos= req.body;

  let nombre= datos.nombre
  let contra= datos.contra
  let correo= datos.correo
  let dni= datos.dni

  let reg="INSERT INTO usuarios (usuario_id, contraseña, correo, dni)VALUES('"+nombre+"','"+contra+"','"+correo+"','"+dni+"')";
  connection.query(reg,function(error){
    if(error){
      throw error;
    }else{
      console.log("bien");
      res.redirect("/inisesion");
    }
  })
})



app.post("/validar2", function(req, res) {
  const da = req.body;

  const nombre = da.username;
  const contra = da.password;

  // Consulta para verificar si el usuario existe en la base de datos y obtener su tipo de usuario
  let query = "SELECT tipo_de_usuario_id FROM usuarios WHERE usuario_id = ? AND contraseña = ?";
  
  // Usa placeholders para evitar inyección SQL
  connection.query(query, [nombre, contra], function(error, results) {
    if (error) {
      throw error;
    }

    if (results.length > 0) {
      // Si el usuario existe, obtenemos su tipo de usuario
      const tipoUsuario = results[0].tipo_de_usuario_id;

      // Redirigir a diferentes páginas según el tipo de usuario
      if (tipoUsuario === 1) {
        res.redirect("/ini"); // Página para usuarios tipo 1 (alumno)
      } else if (tipoUsuario === 2) {
        res.redirect("/ini2"); // Página para usuarios tipo 2 (alumnado)
      } else {
        res.redirect("/espera");
      }
    } else {
      // Si el usuario no existe, mostrar mensaje de error en la misma página
      res.redirect("/home");
    }
  });
});
app.post("/validar3",function(req,res){
  const datos= req.body;

  let nom= datos.nom
  let cur= datos.curso
  let año= datos.año
  let mat= datos.mat
  let nota= datos.nota
  let tipo= datos.tipo

  let regk="INSERT INTO `nota` (usuario_id, curso, año, materia, nota, tipo_de_nota) VALUES('"+nom+"','"+cur+"','"+año+"','"+mat+"','"+nota+"','"+tipo+"')";
  connection.query(regk,function(error){
    if(error){
      throw error;
    }else{
      console.log("bien");
      res.redirect("/selec");
    }
  })
})

